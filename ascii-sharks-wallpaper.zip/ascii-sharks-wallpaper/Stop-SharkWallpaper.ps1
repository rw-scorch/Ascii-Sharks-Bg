param([switch]$Quiet, [switch]$RemoveStartup)

$dir = Split-Path -Parent $MyInvocation.MyCommand.Path
$pidFile = Join-Path $dir "host.pid"

if (Test-Path $pidFile) {
    $old = (Get-Content $pidFile -Raw).Trim()
    $proc = Get-Process -Id $old -ErrorAction SilentlyContinue
    if ($proc -and $proc.ProcessName -match "powershell") { Stop-Process -Id $old -Force }
    Remove-Item $pidFile -Force -ErrorAction SilentlyContinue
}

$oldProfile = Join-Path $dir "edge-profile"
Get-CimInstance Win32_Process -Filter "Name = 'msedge.exe'" |
    Where-Object { $_.CommandLine -and $_.CommandLine.Contains($oldProfile) } |
    ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }

if ($RemoveStartup) {
    $lnk = Join-Path ([Environment]::GetFolderPath("Startup")) "AsciiSharks.lnk"
    if (Test-Path $lnk) { Remove-Item $lnk -Force }
}

if (-not $Quiet) {
    Add-Type @"
using System.Runtime.InteropServices;
public static class SharkPaper {
    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    public static extern bool SystemParametersInfo(int a, int b, string c, int d);
}
"@
    $current = (Get-ItemProperty "HKCU:\Control Panel\Desktop").WallPaper
    [SharkPaper]::SystemParametersInfo(0x14, 0, $current, 3) | Out-Null
    Write-Host "Shark wallpaper stopped."
}
