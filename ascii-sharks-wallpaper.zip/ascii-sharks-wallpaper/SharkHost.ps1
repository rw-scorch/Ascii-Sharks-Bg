$ErrorActionPreference = "Stop"
$dir = Split-Path -Parent $MyInvocation.MyCommand.Path
$log = Join-Path $dir "host.log"
$lib = Join-Path $dir "webview2"
$page = Join-Path $dir "sharks.html"
$profileDir = Join-Path $dir "webview-data"

Set-Content -Path (Join-Path $dir "host.pid") -Value $PID
Set-Content -Path $log -Value "started $(Get-Date)"

try {
    Add-Type @"
using System;
using System.Runtime.InteropServices;
public static class SharkNative {
    public delegate bool EnumProc(IntPtr h, IntPtr l);
    [StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left, Top, Right, Bottom; }
    [DllImport("user32.dll")] static extern bool EnumWindows(EnumProc f, IntPtr l);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern IntPtr FindWindow(string c, string t);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern IntPtr FindWindowEx(IntPtr p, IntPtr a, string c, string t);
    [DllImport("user32.dll")] static extern IntPtr SendMessageTimeout(IntPtr h, uint m, IntPtr w, IntPtr l, uint f, uint t, out IntPtr r);
    [DllImport("user32.dll")] public static extern IntPtr SetParent(IntPtr c, IntPtr p);
    [DllImport("user32.dll")] public static extern IntPtr GetParent(IntPtr h);
    [DllImport("user32.dll")] public static extern bool IsWindow(IntPtr h);
    [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
    [DllImport("user32.dll", EntryPoint = "SetWindowLongPtrW")] static extern IntPtr SetWindowLongPtr(IntPtr h, int i, IntPtr v);
    [DllImport("user32.dll")] static extern bool SetWindowPos(IntPtr h, IntPtr a, int x, int y, int w, int hh, uint f);
    [DllImport("user32.dll")] static extern bool SetProcessDpiAwarenessContext(IntPtr v);
    [DllImport("user32.dll")] static extern bool SetProcessDPIAware();
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode)] public static extern IntPtr LoadLibrary(string p);

    public static void DpiAware() {
        try { if (SetProcessDpiAwarenessContext(new IntPtr(-4))) return; } catch { }
        SetProcessDPIAware();
    }

    public static IntPtr GetWorkerW() {
        IntPtr progman = FindWindow("Progman", null);
        IntPtr r;
        SendMessageTimeout(progman, 0x052C, new IntPtr(0xD), new IntPtr(1), 0, 1000, out r);
        SendMessageTimeout(progman, 0x052C, IntPtr.Zero, IntPtr.Zero, 0, 1000, out r);
        IntPtr inner = FindWindowEx(progman, IntPtr.Zero, "WorkerW", null);
        if (inner != IntPtr.Zero) return inner;
        IntPtr worker = IntPtr.Zero;
        EnumWindows(delegate(IntPtr top, IntPtr l) {
            if (FindWindowEx(top, IntPtr.Zero, "SHELLDLL_DefView", null) != IntPtr.Zero)
                worker = FindWindowEx(IntPtr.Zero, top, "WorkerW", null);
            return true;
        }, IntPtr.Zero);
        return worker;
    }

    public static void Attach(IntPtr win, IntPtr worker, int sx, int sy, int w, int h) {
        RECT wr;
        GetWindowRect(worker, out wr);
        SetWindowLongPtr(win, -16, new IntPtr(0x40000000 | 0x10000000));
        SetWindowLongPtr(win, -20, new IntPtr(0x08000000 | 0x00000080));
        SetParent(win, worker);
        SetWindowPos(win, IntPtr.Zero, sx - wr.Left, sy - wr.Top, w, h, 0x0004 | 0x0010 | 0x0020 | 0x0040);
    }
}
"@

    [SharkNative]::DpiAware()

    $loader = Join-Path $lib "WebView2Loader.dll"
    if ([SharkNative]::LoadLibrary($loader) -eq [IntPtr]::Zero) { throw "Could not load $loader" }
    $env:PATH = "$lib;$env:PATH"

    Add-Type -AssemblyName System.Windows.Forms, System.Drawing
    Add-Type -Path (Join-Path $lib "Microsoft.Web.WebView2.Core.dll")
    Add-Type -Path (Join-Path $lib "Microsoft.Web.WebView2.WinForms.dll")

    $url = ([Uri]$page).AbsoluteUri
    $sharkFile = Join-Path $dir "sharks.txt"
    if (Test-Path $sharkFile) {
        $list = (Get-Content $sharkFile -Raw).Trim()
        if ($list) { $url += "?sharks=$list" }
    }

    $script:forms = @()
    $script:worker = [IntPtr]::Zero
    $script:layout = ""

    function Get-Layout {
        ([System.Windows.Forms.Screen]::AllScreens | ForEach-Object { $_.Bounds.ToString() }) -join "|"
    }

    function Clear-Walls {
        foreach ($f in $script:forms) {
            try { $f.Close(); $f.Dispose() } catch { }
        }
        $script:forms = @()
    }

    function Build-Walls {
        Clear-Walls
        $script:worker = [SharkNative]::GetWorkerW()
        if ($script:worker -eq [IntPtr]::Zero) { throw "Desktop WorkerW window not found." }
        $script:layout = Get-Layout

        foreach ($screen in [System.Windows.Forms.Screen]::AllScreens) {
            $b = $screen.Bounds
            $f = New-Object System.Windows.Forms.Form
            $f.FormBorderStyle = "None"
            $f.ShowInTaskbar = $false
            $f.StartPosition = "Manual"
            $f.BackColor = [System.Drawing.Color]::Black
            $f.Bounds = $b

            $wv = New-Object Microsoft.Web.WebView2.WinForms.WebView2
            $props = New-Object Microsoft.Web.WebView2.WinForms.CoreWebView2CreationProperties
            $props.UserDataFolder = $profileDir
            $props.AdditionalBrowserArguments = "--disable-features=CalculateNativeWinOcclusion --disable-background-timer-throttling --disable-renderer-backgrounding --disable-backgrounding-occluded-windows"
            $wv.CreationProperties = $props
            $wv.DefaultBackgroundColor = [System.Drawing.Color]::Black
            $wv.Dock = "Fill"
            $f.Controls.Add($wv)

            $f.Show()
            [SharkNative]::Attach($f.Handle, $script:worker, $b.X, $b.Y, $b.Width, $b.Height)
            $wv.Source = [Uri]$url
            $script:forms += $f
            Add-Content $log "screen $b attached"
        }
    }

    Build-Walls

    $timer = New-Object System.Windows.Forms.Timer
    $timer.Interval = 3000
    $timer.Add_Tick({
        try {
            $lost = -not [SharkNative]::IsWindow($script:worker)
            foreach ($f in $script:forms) {
                if ([SharkNative]::GetParent($f.Handle) -ne $script:worker) { $lost = $true }
            }
            if ($lost -or (Get-Layout) -ne $script:layout) {
                Add-Content $log "rebuilding $(Get-Date)"
                Build-Walls
            }
        } catch {
            Add-Content $log "tick error: $_"
        }
    })
    $timer.Start()

    $ctx = New-Object System.Windows.Forms.ApplicationContext
    [System.Windows.Forms.Application]::Run($ctx)
} catch {
    Add-Content $log "fatal: $_"
    Add-Content $log $_.ScriptStackTrace
    exit 1
}
