import { readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";

const repo = process.argv[2];
if (!repo) {
  console.error("usage: node patch-sharks.mjs <repo dir>");
  process.exit(2);
}

const patches = {
  "src/renderer.ts": [
    ["    paintGrid(g, W, H, cw, ch, dpr);\n  }", "  }"],
    ["    this.drawDots(t);\n", ""],
    [
      "        ctx.fillStyle =\n          roll < 0.07\n            ? ACCENTS[key % ACCENTS.length]\n            : `rgb(${Math.round(g * tr)},${Math.round(g * tg)},${Math.min(255, Math.round(g * tb + 6))})`;",
      "        const ge = Math.round(g);\n        ctx.fillStyle = `rgb(${ge},${ge},${ge})`;",
    ],
    ["      ctx.fillRect(x + 1, y + 1, cw - 1, ch - 1);\n", ""],
    [
      /      let color: string;\n[\s\S]*?      ctx\.fillStyle = color;\n/,
      "      const gv = Math.min(255, Math.round(70 + level * 0.85));\n      ctx.fillStyle = flag === FLAG_EYE ? \"#ffffff\" : `rgb(${gv},${gv},${gv})`;\n",
    ],
    [/      ctx\.fillStyle = `rgb\(\$\{Math\.min\(255, Math\.round\(level \* tr\)\)\}[^\n]*\n/, ""],
    ["rgba(230,238,255,${a})", "rgba(235,235,235,${a})"],
    [
      /ctx\.fillStyle = h > 0\.5 \? `rgba\(255,120,60[^\n]*/,
      "ctx.fillStyle = `rgba(255,255,255,${Math.min(1, h).toFixed(2)})`;",
    ],
  ],
  "src/engine.ts": [
    ['window.matchMedia("(prefers-reduced-motion: reduce)")', 'window.matchMedia("not all")'],
  ],
};

let failed = 0;
for (const [file, list] of Object.entries(patches)) {
  const path = join(repo, file);
  let text = readFileSync(path, "utf8").replace(/\r\n/g, "\n");
  for (const [from, to] of list) {
    const hit = typeof from === "string" ? text.includes(from) : from.test(text);
    if (!hit) {
      console.error(`patch miss in ${file}: ${String(from).slice(0, 60)}`);
      failed++;
      continue;
    }
    text = text.replace(from, to);
  }
  writeFileSync(path, text);
}

if (failed) process.exit(1);
console.log("patched");
