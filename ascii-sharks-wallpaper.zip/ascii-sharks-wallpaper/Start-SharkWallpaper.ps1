$ErrorActionPreference = "Stop"
$dir = Split-Path -Parent $MyInvocation.MyCommand.Path
$hostScript = Join-Path $dir "SharkHost.ps1"
$log = Join-Path $dir "host.log"

foreach ($need in "sharks.html", "SharkHost.ps1", "webview2\Microsoft.Web.WebView2.WinForms.dll") {
    if (-not (Test-Path (Join-Path $dir $need))) { throw "$need missing. Run Install-SharkWallpaper.ps1 first." }
}

& (Join-Path $dir "Stop-SharkWallpaper.ps1") -Quiet

$p = Start-Process powershell.exe -WindowStyle Hidden -PassThru -ArgumentList @(
    "-NoProfile", "-STA", "-ExecutionPolicy", "Bypass", "-File", "`"$hostScript`""
)

Start-Sleep -Seconds 4
if ($p.HasExited) {
    Write-Host "Shark host crashed. Log:" -ForegroundColor Red
    if (Test-Path $log) { Get-Content $log | Write-Host }
    exit 1
}
Write-Host "Sharks are swimming on every monitor."
