param(
    [string]$InstallDir = "$env:LOCALAPPDATA\AsciiSharks",
    [string]$Sharks = "",
    [switch]$Startup
)

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$WebView2Version = "1.0.2903.40"

New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
if (Test-Path (Join-Path $InstallDir "Stop-SharkWallpaper.ps1")) {
    & (Join-Path $InstallDir "Stop-SharkWallpaper.ps1") -Quiet
}

$zip = Join-Path $InstallDir "repo.zip"
$src = Join-Path $InstallDir "source"

Write-Host "Downloading stackedlol/ascii-sharks..."
$got = $false
foreach ($branch in "main", "master") {
    try {
        Invoke-WebRequest "https://codeload.github.com/stackedlol/ascii-sharks/zip/refs/heads/$branch" -OutFile $zip -UseBasicParsing
        $got = $true
        break
    } catch { }
}
if (-not $got) { throw "Could not download repo from GitHub." }

if (Test-Path $src) { Remove-Item $src -Recurse -Force }
Expand-Archive $zip -DestinationPath $src -Force
$repo = Get-ChildItem $src -Directory | Select-Object -First 1
Write-Host "Extracted to $($repo.FullName)"

$page = Join-Path $InstallDir "sharks.html"
$built = $false

if ((Get-Command node -ErrorAction SilentlyContinue) -and (Get-Command npx -ErrorAction SilentlyContinue)) {
    Write-Host "Node found, patching to black and white and building from source..."
    $js = Join-Path $InstallDir "sharks.js"
    $entry = Join-Path $repo.FullName "demo.ts"
    if (Test-Path $js) { Remove-Item $js -Force }
    $prevEap = $ErrorActionPreference
    $ErrorActionPreference = "Continue"
    Push-Location $InstallDir
    try {
        & node (Join-Path $here "patch-sharks.mjs") $repo.FullName *> $null
        if ($LASTEXITCODE -eq 0) {
            & npx --yes esbuild@0.24 $entry --bundle --format=iife --minify --target=es2020 "--outfile=$js" *> $null
        } else {
            Write-Host "Repo changed upstream, patch did not apply."
        }
        if ((Test-Path $js) -and (Get-Item $js).Length -gt 1000) {
            $code = (Get-Content $js -Raw) -replace "</script", "<\/script"
            $template = Get-Content (Join-Path $here "prebuilt\sharks.html") -Raw
            $head = $template.Substring(0, $template.IndexOf("<script>") + 8)
            $tail = $template.Substring($template.LastIndexOf("</script>"))
            Set-Content -Path $page -Value ($head + $code + $tail) -Encoding UTF8
            $built = $true
            Write-Host "Built from source."
        }
    } catch {
        Write-Host "Source build failed."
    } finally {
        Pop-Location
        $ErrorActionPreference = $prevEap
    }
}

if (-not $built) {
    Write-Host "Using bundled prebuilt black and white page."
    Copy-Item (Join-Path $here "prebuilt\sharks.html") $page -Force
}

$wvDir = Join-Path $InstallDir "webview2"
if (-not (Test-Path (Join-Path $wvDir "Microsoft.Web.WebView2.WinForms.dll"))) {
    Write-Host "Downloading WebView2 libraries..."
    $nupkg = Join-Path $InstallDir "webview2.zip"
    $nuDir = Join-Path $InstallDir "webview2-pkg"
    Invoke-WebRequest "https://www.nuget.org/api/v2/package/Microsoft.Web.WebView2/$WebView2Version" -OutFile $nupkg -UseBasicParsing
    if (Test-Path $nuDir) { Remove-Item $nuDir -Recurse -Force }
    Expand-Archive $nupkg -DestinationPath $nuDir -Force
    $arch = switch ($env:PROCESSOR_ARCHITECTURE) { "ARM64" { "win-arm64" } "x86" { "win-x86" } default { "win-x64" } }
    New-Item -ItemType Directory -Force -Path $wvDir | Out-Null
    Copy-Item (Join-Path $nuDir "lib\net462\Microsoft.Web.WebView2.Core.dll") $wvDir -Force
    Copy-Item (Join-Path $nuDir "lib\net462\Microsoft.Web.WebView2.WinForms.dll") $wvDir -Force
    Copy-Item (Join-Path $nuDir "runtimes\$arch\native\WebView2Loader.dll") $wvDir -Force
    Get-ChildItem $wvDir | Unblock-File
    Remove-Item $nuDir -Recurse -Force
    Remove-Item $nupkg -Force
}

foreach ($f in "SharkHost.ps1", "Start-SharkWallpaper.ps1", "Stop-SharkWallpaper.ps1") {
    Copy-Item (Join-Path $here $f) $InstallDir -Force
}
Set-Content -Path (Join-Path $InstallDir "sharks.txt") -Value $Sharks

$old = Join-Path $InstallDir "edge-profile"
if (Test-Path $old) { Remove-Item $old -Recurse -Force -ErrorAction SilentlyContinue }

$lnk = Join-Path ([Environment]::GetFolderPath("Startup")) "AsciiSharks.lnk"
if ($Startup) {
    $sh = New-Object -ComObject WScript.Shell
    $s = $sh.CreateShortcut($lnk)
    $s.TargetPath = "powershell.exe"
    $s.Arguments = "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$InstallDir\Start-SharkWallpaper.ps1`""
    $s.WorkingDirectory = $InstallDir
    $s.Save()
    Write-Host "Added to startup: $lnk"
}

& (Join-Path $InstallDir "Start-SharkWallpaper.ps1")
